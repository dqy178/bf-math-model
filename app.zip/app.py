"""高炉检测软件数学模型计算器 —— Streamlit 入口。

启动：
    streamlit run app.py
"""

from __future__ import annotations

import os

from bfmodels.registry import MODELS
from bfmodels.ui import render_app

SOURCE_FILE = "高炉检测软件数学模型.xlsx"


def main() -> None:
    here = os.path.dirname(os.path.abspath(__file__))
    src = os.path.join(here, SOURCE_FILE)
    render_app(MODELS, source_file=SOURCE_FILE if os.path.exists(src) else SOURCE_FILE)


if __name__ == "__main__":
    main()
